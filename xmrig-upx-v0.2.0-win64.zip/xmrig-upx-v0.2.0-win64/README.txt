Make sure to edit config.json
Replace:
            "user": "YOUR_UPX_ADDRESS_HERE",
With your UPX address.

If you are using highend devices, change upx.poolbux.com:3333 to upx.poolbux.com:7777

NOTE:
Use cryptonight-upx for STANDARD algorithm (v1)
Use cryptonight-upx/2 or cryptonight-plex for UPXTWO (v2) (April 29th update, 2019)

Patches:
v0.2.0 - Support for UPXTWO


If you're on Linux and running into depdency issues, install the following:
(Ubuntu)::
sudo apt-get install git build-essential cmake libuv1-dev libmicrohttpd-dev libssl-dev